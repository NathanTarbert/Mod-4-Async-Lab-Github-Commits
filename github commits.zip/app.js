function loadCommits() {
    
    let username = document.getElementById("username").value;
    let repo = document.getElementById("repo").value;
    let commits = document.getElementById("commits");
    let urlLInk = `https://api.github.com/repos/${username}/${repo}/commits`;

    fetch(urlLInk)//pass link into fetch
    .then((response) => {
        if(response.status == 200){
            return response.json();//convert what's inside the url link and parse it so we can use it
        }else {
            throw new TypeError(response.statusText);
        }
    })
    .then((username) => {
        console.log("get this data",username);
      username.map((data) => {
          let newListItem = document.createElement("ul");
          let newLi = document.createElement('li');
          newListItem.textContent = `${data.commit.author.name} : ${data.commit.message}`;
          newLi.appendChild(newListItem);
          commits.appendChild(newLi);
          
      });
    })
    .catch((error) => {
        console.log(error);
        commits.innerHTML = `<li>${error}</li>`;
}); 
}